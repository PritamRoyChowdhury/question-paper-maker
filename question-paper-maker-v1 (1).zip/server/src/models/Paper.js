const mongoose = require("mongoose");

const paperSchema = new mongoose.Schema({
  title: { type: String, default: "Question Paper" },
  schoolName: { type: String, default: "" },
  className: { type: String, required: true },
  subject: { type: String, required: true },
  duration: { type: String, default: "3 Hours" },
  totalMarks: { type: Number, required: true },
  instructions: [{ type: String }],
  sections: [{
    name: String,
    questionType: String,
    marksPerQuestion: Number,
    count: Number,
    questions: [{ type: mongoose.Schema.Types.ObjectId, ref: "Question" }]
  }],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
}, { timestamps: true });

module.exports = mongoose.model("Paper", paperSchema);
