const mongoose = require("mongoose");

const questionSchema = new mongoose.Schema({
  className: { type: String, required: true, trim: true },
  subject: { type: String, required: true, trim: true },
  chapter: { type: String, default: "", trim: true },
  type: {
    type: String,
    enum: ["MCQ", "True/False", "Fill in the Blanks", "Very Short", "Short", "Long", "Case Based", "Numerical"],
    required: true
  },
  difficulty: {
    type: String,
    enum: ["Easy", "Moderate", "Hard"],
    default: "Moderate"
  },
  text: { type: String, required: true, trim: true },
  options: [{ type: String, trim: true }],
  answer: { type: String, default: "" },
  solution: { type: String, default: "" },
  marks: { type: Number, required: true, min: 1, max: 100 },
  tags: [{ type: String, trim: true }],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
}, { timestamps: true });

module.exports = mongoose.model("Question", questionSchema);
