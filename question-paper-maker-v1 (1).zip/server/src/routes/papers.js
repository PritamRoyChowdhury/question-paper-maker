const router = require("express").Router();
const Question = require("../models/Question");
const Paper = require("../models/Paper");
const auth = require("../middleware/auth");

router.use(auth);

function shuffle(items) {
  const a = [...items];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

router.post("/generate", async (req, res, next) => {
  try {
    const {
      title = "Question Paper",
      schoolName = "",
      className,
      subject,
      duration = "3 Hours",
      totalMarks,
      instructions = [],
      sections = []
    } = req.body;

    if (!className || !subject || !totalMarks || !Array.isArray(sections)) {
      return res.status(400).json({ message: "className, subject, totalMarks and sections are required" });
    }

    const generatedSections = [];
    let calculatedTotal = 0;

    for (const section of sections) {
      const count = Number(section.count);
      const marksPerQuestion = Number(section.marksPerQuestion);

      if (!count || !marksPerQuestion) {
        return res.status(400).json({ message: "Each section needs count and marksPerQuestion" });
      }

      const filter = {
        className,
        subject,
        marks: marksPerQuestion
      };

      if (section.questionType) filter.type = section.questionType;
      if (section.difficulty) filter.difficulty = section.difficulty;

      const pool = await Question.find(filter).lean();

      if (pool.length < count) {
        return res.status(400).json({
          message: `Not enough questions for section "${section.name || "Section"}". Need ${count}, found ${pool.length}.`
        });
      }

      const selected = shuffle(pool).slice(0, count);
      calculatedTotal += count * marksPerQuestion;

      generatedSections.push({
        name: section.name || "Section",
        questionType: section.questionType || "Mixed",
        marksPerQuestion,
        count,
        questions: selected.map(q => q._id)
      });
    }

    if (calculatedTotal !== Number(totalMarks)) {
      return res.status(400).json({
        message: `Section marks total ${calculatedTotal}, but totalMarks is ${totalMarks}.`
      });
    }

    const paper = await Paper.create({
      title, schoolName, className, subject, duration,
      totalMarks: Number(totalMarks),
      instructions,
      sections: generatedSections,
      createdBy: req.user.id
    });

    const populated = await Paper.findById(paper._id)
      .populate("sections.questions");

    res.status(201).json(populated);
  } catch (e) { next(e); }
});

router.get("/", async (req, res, next) => {
  try {
    const papers = await Paper.find({ createdBy: req.user.id })
      .sort({ createdAt: -1 })
      .limit(100);
    res.json(papers);
  } catch (e) { next(e); }
});

router.get("/:id", async (req, res, next) => {
  try {
    const paper = await Paper.findOne({
      _id: req.params.id,
      createdBy: req.user.id
    }).populate("sections.questions");

    if (!paper) return res.status(404).json({ message: "Paper not found" });
    res.json(paper);
  } catch (e) { next(e); }
});

router.delete("/:id", async (req, res, next) => {
  try {
    await Paper.findOneAndDelete({ _id: req.params.id, createdBy: req.user.id });
    res.json({ message: "Paper deleted" });
  } catch (e) { next(e); }
});

module.exports = router;
