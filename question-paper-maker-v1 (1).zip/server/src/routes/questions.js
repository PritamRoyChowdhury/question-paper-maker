const router = require("express").Router();
const Question = require("../models/Question");
const auth = require("../middleware/auth");

router.use(auth);

router.get("/", async (req, res, next) => {
  try {
    const filter = {};
    ["className", "subject", "chapter", "type", "difficulty"].forEach(key => {
      if (req.query[key]) filter[key] = req.query[key];
    });

    if (req.query.search) {
      filter.text = { $regex: req.query.search, $options: "i" };
    }

    const questions = await Question.find(filter)
      .sort({ createdAt: -1 })
      .limit(1000);

    res.json(questions);
  } catch (e) { next(e); }
});

router.post("/", async (req, res, next) => {
  try {
    const data = { ...req.body, createdBy: req.user.id };
    const question = await Question.create(data);
    res.status(201).json(question);
  } catch (e) { next(e); }
});

router.put("/:id", async (req, res, next) => {
  try {
    const question = await Question.findOneAndUpdate(
      { _id: req.params.id, createdBy: req.user.id },
      req.body,
      { new: true, runValidators: true }
    );
    if (!question) return res.status(404).json({ message: "Question not found" });
    res.json(question);
  } catch (e) { next(e); }
});

router.delete("/:id", async (req, res, next) => {
  try {
    const question = await Question.findOneAndDelete({
      _id: req.params.id,
      createdBy: req.user.id
    });
    if (!question) return res.status(404).json({ message: "Question not found" });
    res.json({ message: "Question deleted" });
  } catch (e) { next(e); }
});

module.exports = router;
