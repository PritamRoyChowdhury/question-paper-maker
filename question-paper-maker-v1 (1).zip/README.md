# Automatic Question Paper Maker — Version 1

A deployable React + Node.js + MongoDB application for managing a question bank and automatically generating question papers.

## Features

- Admin/teacher registration and login with JWT
- MongoDB question bank
- Add, edit, delete and search questions
- Filter by class, subject, chapter, type and difficulty
- Automatic paper generation from selected requirements
- Prevents duplicate questions in a generated paper
- Paper preview
- Download generated paper as PDF
- Download generated paper as DOCX
- Responsive Bootstrap UI

## Requirements

- Node.js 18+
- MongoDB local installation or MongoDB Atlas
- npm

## 1. Backend

```bash
cd server
npm install
copy .env.example .env
```

Edit `.env`:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/question_paper_maker
JWT_SECRET=replace_with_a_long_random_secret
CLIENT_URL=http://localhost:3000
```

Start:

```bash
npm run dev
```

Backend runs at `http://localhost:5000`.

## 2. Frontend

Open another terminal:

```bash
cd client
npm install
npm start
```

Frontend runs at `http://localhost:3000`.

## 3. First use

1. Register a user.
2. Log in.
3. Add questions to the question bank.
4. Open Generate Paper.
5. Select class, subject, marks, duration and question distribution.
6. Generate and preview.
7. Download PDF or DOCX.

## Deployment

### MongoDB
Use MongoDB Atlas and copy the connection string into the backend environment variables.

### Backend
Deploy `server` to Render, Railway, or another Node hosting service.

Environment variables:

- `PORT`
- `MONGO_URI`
- `JWT_SECRET`
- `CLIENT_URL`

### Frontend
Deploy `client` to Vercel, Netlify, or another static hosting service.

Create:

```env
REACT_APP_API_URL=https://YOUR-BACKEND-DOMAIN/api
```

Do not put the MongoDB URI or JWT secret in the React frontend.
