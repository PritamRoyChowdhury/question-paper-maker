import React, { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, Navigate, Link, useNavigate } from "react-router-dom";
import { jsPDF } from "jspdf";
import { Document, Packer, Paragraph, TextRun, AlignmentType } from "docx";
import { saveAs } from "file-saver";
import api from "./api";

const TYPES = ["MCQ","True/False","Fill in the Blanks","Very Short","Short","Long","Case Based","Numerical"];
const DIFFICULTIES = ["Easy","Moderate","Hard"];

function Protected({ children }) {
  return localStorage.getItem("qpm_token") ? children : <Navigate to="/login" replace />;
}

function Navbar() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("qpm_user") || "null");
  function logout() {
    localStorage.clear();
    navigate("/login");
  }
  return (
    <nav className="navbar navbar-dark bg-dark no-print">
      <div className="container">
        <Link className="navbar-brand fw-bold" to="/">Question Paper Maker</Link>
        <div className="d-flex gap-2 align-items-center">
          <Link className="btn btn-sm btn-outline-light" to="/questions">Question Bank</Link>
          <Link className="btn btn-sm btn-outline-light" to="/generate">Generate Paper</Link>
          <span className="text-white small">{user?.name}</span>
          <button className="btn btn-sm btn-danger" onClick={logout}>Logout</button>
        </div>
      </div>
    </nav>
  );
}

function Layout({ children }) {
  return <><Navbar /><main className="container py-4">{children}</main></>;
}

function Login() {
  const navigate = useNavigate();
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name:"", email:"", password:"", role:"teacher" });
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault(); setError("");
    try {
      const url = mode === "login" ? "/auth/login" : "/auth/register";
      const { data } = await api.post(url, form);
      localStorage.setItem("qpm_token", data.token);
      localStorage.setItem("qpm_user", JSON.stringify(data.user));
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || "Request failed");
    }
  }

  return (
    <div className="row justify-content-center mt-5">
      <div className="col-md-5">
        <div className="card p-4">
          <h2 className="mb-3">Question Paper Maker</h2>
          <p className="text-muted">{mode === "login" ? "Sign in" : "Create an account"}</p>
          {error && <div className="alert alert-danger">{error}</div>}
          <form onSubmit={submit}>
            {mode === "register" && <input className="form-control mb-3" placeholder="Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required />}
            <input className="form-control mb-3" type="email" placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required />
            <input className="form-control mb-3" type="password" placeholder="Password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required minLength="6" />
            {mode === "register" && <select className="form-select mb-3" value={form.role} onChange={e=>setForm({...form,role:e.target.value})}><option value="teacher">Teacher</option><option value="admin">Admin</option></select>}
            <button className="btn btn-dark w-100">{mode === "login" ? "Login" : "Register"}</button>
          </form>
          <button className="btn btn-link mt-2" onClick={()=>setMode(mode==="login"?"register":"login")}>
            {mode === "login" ? "Create account" : "Already have an account? Login"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Dashboard() {
  const [stats, setStats] = useState({questions:0,papers:0});
  useEffect(() => {
    Promise.all([api.get("/questions"), api.get("/papers")]).then(([q,p]) => {
      setStats({questions:q.data.length,papers:p.data.length});
    });
  }, []);
  return (
    <Layout>
      <h1 className="mb-4">Dashboard</h1>
      <div className="row g-3">
        <div className="col-md-6"><div className="card p-4"><h6>Total Questions</h6><h2>{stats.questions}</h2><Link to="/questions">Manage Question Bank →</Link></div></div>
        <div className="col-md-6"><div className="card p-4"><h6>Papers Created</h6><h2>{stats.papers}</h2><Link to="/generate">Generate New Paper →</Link></div></div>
      </div>
    </Layout>
  );
}

const emptyQuestion = {
  className:"XI", subject:"Mathematics", chapter:"", type:"MCQ", difficulty:"Moderate",
  text:"", options:["","","",""], answer:"", solution:"", marks:1, tags:[]
};

function Questions() {
  const [questions,setQuestions] = useState([]);
  const [form,setForm] = useState(emptyQuestion);
  const [editing,setEditing] = useState(null);
  const [filters,setFilters] = useState({className:"",subject:"",type:"",difficulty:"",search:""});
  const [error,setError] = useState("");

  async function load() {
    const {data}=await api.get("/questions",{params:filters});
    setQuestions(data);
  }
  useEffect(()=>{load()},[]);

  function update(k,v){setForm({...form,[k]:v});}

  async function save(e) {
    e.preventDefault(); setError("");
    try {
      const payload={...form, marks:Number(form.marks), options:form.type==="MCQ"?form.options.filter(Boolean):[]};
      if(editing) await api.put(`/questions/${editing}`,payload);
      else await api.post("/questions",payload);
      setForm(emptyQuestion); setEditing(null); load();
    } catch(err){setError(err.response?.data?.message || "Could not save question");}
  }

  async function remove(id){
    if(!window.confirm("Delete this question?")) return;
    await api.delete(`/questions/${id}`); load();
  }

  function edit(q){
    setEditing(q._id);
    setForm({...q, options:q.options?.length?q.options:["","","",""]});
    window.scrollTo({top:0,behavior:"smooth"});
  }

  return (
    <Layout>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2>Question Bank</h2><Link className="btn btn-primary" to="/generate">Generate Paper</Link>
      </div>

      <div className="card p-4 mb-4">
        <h5>{editing ? "Edit Question" : "Add Question"}</h5>
        {error && <div className="alert alert-danger">{error}</div>}
        <form onSubmit={save}>
          <div className="row g-2">
            <div className="col-md-2"><input className="form-control" placeholder="Class" value={form.className} onChange={e=>update("className",e.target.value)} required /></div>
            <div className="col-md-3"><input className="form-control" placeholder="Subject" value={form.subject} onChange={e=>update("subject",e.target.value)} required /></div>
            <div className="col-md-3"><input className="form-control" placeholder="Chapter" value={form.chapter} onChange={e=>update("chapter",e.target.value)} /></div>
            <div className="col-md-2"><select className="form-select" value={form.type} onChange={e=>update("type",e.target.value)}>{TYPES.map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="col-md-2"><select className="form-select" value={form.difficulty} onChange={e=>update("difficulty",e.target.value)}>{DIFFICULTIES.map(x=><option key={x}>{x}</option>)}</select></div>
          </div>
          <textarea className="form-control mt-2" rows="3" placeholder="Question text" value={form.text} onChange={e=>update("text",e.target.value)} required />
          {form.type==="MCQ" && <div className="row g-2 mt-1">{form.options.map((o,i)=><div className="col-md-6" key={i}><input className="form-control" placeholder={`Option ${String.fromCharCode(65+i)}`} value={o} onChange={e=>{const a=[...form.options];a[i]=e.target.value;update("options",a)}} /></div>)}</div>}
          <div className="row g-2 mt-1">
            <div className="col-md-2"><input className="form-control" type="number" min="1" placeholder="Marks" value={form.marks} onChange={e=>update("marks",e.target.value)} required /></div>
            <div className="col-md-10"><input className="form-control" placeholder="Answer" value={form.answer} onChange={e=>update("answer",e.target.value)} /></div>
          </div>
          <textarea className="form-control mt-2" rows="2" placeholder="Solution / marking notes" value={form.solution} onChange={e=>update("solution",e.target.value)} />
          <div className="mt-3">
            <button className="btn btn-success me-2">{editing?"Update Question":"Add Question"}</button>
            {editing && <button type="button" className="btn btn-secondary" onClick={()=>{setEditing(null);setForm(emptyQuestion)}}>Cancel</button>}
          </div>
        </form>
      </div>

      <div className="card p-3 mb-3">
        <h6>Search / Filter</h6>
        <div className="row g-2">
          {["className","subject","type","difficulty"].map(k=><div className="col-md-2" key={k}>
            {["type","difficulty"].includes(k) ?
              <select className="form-select" value={filters[k]} onChange={e=>setFilters({...filters,[k]:e.target.value})}><option value="">{k}</option>{(k==="type"?TYPES:DIFFICULTIES).map(x=><option key={x}>{x}</option>)}</select> :
              <input className="form-control" placeholder={k} value={filters[k]} onChange={e=>setFilters({...filters,[k]:e.target.value})}/>}
          </div>)}
          <div className="col-md-3"><input className="form-control" placeholder="Search question text" value={filters.search} onChange={e=>setFilters({...filters,search:e.target.value})}/></div>
          <div className="col-md-1"><button className="btn btn-dark" onClick={load}>Go</button></div>
        </div>
      </div>

      <div className="table-responsive">
        <table className="table table-bordered bg-white align-middle">
          <thead><tr><th>Class</th><th>Subject</th><th>Type</th><th>Difficulty</th><th>Question</th><th>Marks</th><th>Actions</th></tr></thead>
          <tbody>{questions.map(q=><tr key={q._id}><td>{q.className}</td><td>{q.subject}</td><td>{q.type}</td><td>{q.difficulty}</td><td>{q.text}</td><td>{q.marks}</td><td className="text-nowrap"><button className="btn btn-sm btn-outline-primary me-1" onClick={()=>edit(q)}>Edit</button><button className="btn btn-sm btn-outline-danger" onClick={()=>remove(q._id)}>Delete</button></td></tr>)}</tbody>
        </table>
      </div>
    </Layout>
  );
}

function Generate() {
  const [form,setForm]=useState({
    title:"CLASS XI – MATHEMATICS",
    schoolName:"DON BOSCO SCHOOL",
    className:"XI", subject:"Mathematics", duration:"3 Hours", totalMarks:80,
    instructions:["All questions are compulsory.","Read the questions carefully before answering."]
  });
  const [sections,setSections]=useState([
    {name:"Section A",questionType:"MCQ",marksPerQuestion:1,count:20,difficulty:""},
    {name:"Section B",questionType:"Very Short",marksPerQuestion:2,count:5,difficulty:""},
    {name:"Section C",questionType:"Short",marksPerQuestion:3,count:5,difficulty:""},
    {name:"Section D",questionType:"Long",marksPerQuestion:5,count:5,difficulty:""}
  ]);
  const [paper,setPaper]=useState(null);
  const [error,setError]=useState("");

  const total=sections.reduce((s,x)=>s+Number(x.count||0)*Number(x.marksPerQuestion||0),0);

  function changeSection(i,k,v){const a=[...sections];a[i]={...a[i],[k]:v};setSections(a);}
  function addSection(){setSections([...sections,{name:`Section ${String.fromCharCode(65+sections.length)}`,questionType:"Short",marksPerQuestion:2,count:1,difficulty:""}]);}
  function removeSection(i){setSections(sections.filter((_,idx)=>idx!==i));}

  async function generate(e){
    e.preventDefault();setError("");setPaper(null);
    try {
      const {data}=await api.post("/papers/generate",{...form,totalMarks:Number(form.totalMarks),sections:sections.map(s=>({...s,count:Number(s.count),marksPerQuestion:Number(s.marksPerQuestion)}))});
      setPaper(data);
    } catch(err){setError(err.response?.data?.message || "Could not generate paper");}
  }

  function downloadPDF(){
    const doc=new jsPDF();
    let y=18;
    const line=(text,size=11,bold=false)=>{doc.setFontSize(size);doc.setFont("helvetica",bold?"bold":"normal");const lines=doc.splitTextToSize(text,180);doc.text(lines,15,y);y+=lines.length*6+3;if(y>275){doc.addPage();y=18;}};
    line(paper.schoolName,16,true);line(paper.title,14,true);line(`Time: ${paper.duration}    Maximum Marks: ${paper.totalMarks}`,11,false);y+=4;
    line("General Instructions",12,true);paper.instructions.forEach((x,i)=>line(`${i+1}. ${x}`));
    let qno=1;
    paper.sections.forEach(sec=>{y+=4;line(`${sec.name} (${sec.marksPerQuestion} marks each)`,13,true);sec.questions.forEach(q=>{line(`${qno}. ${q.text}`,11,false);if(q.type==="MCQ"&&q.options?.length){q.options.forEach((o,i)=>line(`   ${String.fromCharCode(65+i)}. ${o}`));}qno++;});});
    doc.save("question-paper.pdf");
  }

  async function downloadDOCX(){
    const children=[];
    children.push(new Paragraph({children:[new TextRun({text:paper.schoolName,bold:true,size:32})],alignment:AlignmentType.CENTER}));
    children.push(new Paragraph({children:[new TextRun({text:paper.title,bold:true,size:28})],alignment:AlignmentType.CENTER}));
    children.push(new Paragraph({text:`Time: ${paper.duration}    Maximum Marks: ${paper.totalMarks}`}));
    children.push(new Paragraph({children:[new TextRun({text:"General Instructions",bold:true})]}));
    paper.instructions.forEach((x,i)=>children.push(new Paragraph({text:`${i+1}. ${x}`})));
    let qno=1;
    paper.sections.forEach(sec=>{
      children.push(new Paragraph({children:[new TextRun({text:`${sec.name} (${sec.marksPerQuestion} marks each)`,bold:true})]}));
      sec.questions.forEach(q=>{
        children.push(new Paragraph({text:`${qno}. ${q.text}`}));
        if(q.type==="MCQ"&&q.options?.length) q.options.forEach((o,i)=>children.push(new Paragraph({text:`   ${String.fromCharCode(65+i)}. ${o}`})));
        qno++;
      });
    });
    const blob=await Packer.toBlob(new Document({sections:[{children}]}));
    saveAs(blob,"question-paper.docx");
  }

  return (
    <Layout>
      <h2>Automatic Paper Generator</h2>
      <div className="card p-4 mt-3">
        {error&&<div className="alert alert-danger">{error}</div>}
        <form onSubmit={generate}>
          <div className="row g-2">
            <div className="col-md-6"><label className="form-label">Paper Title</label><input className="form-control" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></div>
            <div className="col-md-6"><label className="form-label">School Name</label><input className="form-control" value={form.schoolName} onChange={e=>setForm({...form,schoolName:e.target.value})}/></div>
            <div className="col-md-3"><label className="form-label">Class</label><input className="form-control" value={form.className} onChange={e=>setForm({...form,className:e.target.value})}/></div>
            <div className="col-md-3"><label className="form-label">Subject</label><input className="form-control" value={form.subject} onChange={e=>setForm({...form,subject:e.target.value})}/></div>
            <div className="col-md-3"><label className="form-label">Duration</label><input className="form-control" value={form.duration} onChange={e=>setForm({...form,duration:e.target.value})}/></div>
            <div className="col-md-3"><label className="form-label">Total Marks</label><input className="form-control" type="number" value={form.totalMarks} onChange={e=>setForm({...form,totalMarks:e.target.value})}/></div>
          </div>

          <hr/>
          <div className="d-flex justify-content-between"><h5>Sections</h5><span className={total===Number(form.totalMarks)?"text-success":"text-danger"}>Calculated: {total} / {form.totalMarks}</span></div>
          {sections.map((s,i)=><div className="row g-2 mb-2 align-items-end" key={i}>
            <div className="col-md-2"><label className="small">Section</label><input className="form-control" value={s.name} onChange={e=>changeSection(i,"name",e.target.value)}/></div>
            <div className="col-md-3"><label className="small">Question Type</label><select className="form-select" value={s.questionType} onChange={e=>changeSection(i,"questionType",e.target.value)}><option value="">Mixed</option>{TYPES.map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="col-md-2"><label className="small">Marks / Q</label><input className="form-control" type="number" min="1" value={s.marksPerQuestion} onChange={e=>changeSection(i,"marksPerQuestion",e.target.value)}/></div>
            <div className="col-md-2"><label className="small">No. of Questions</label><input className="form-control" type="number" min="1" value={s.count} onChange={e=>changeSection(i,"count",e.target.value)}/></div>
            <div className="col-md-2"><label className="small">Difficulty</label><select className="form-select" value={s.difficulty} onChange={e=>changeSection(i,"difficulty",e.target.value)}><option value="">Any</option>{DIFFICULTIES.map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="col-md-1"><button type="button" className="btn btn-outline-danger" onClick={()=>removeSection(i)}>×</button></div>
          </div>)}
          <button type="button" className="btn btn-outline-secondary me-2" onClick={addSection}>+ Add Section</button>
          <button className="btn btn-primary" disabled={total!==Number(form.totalMarks)}>Generate Paper</button>
        </form>
      </div>

      {paper && <div className="mt-4">
        <div className="d-flex gap-2 mb-3 no-print">
          <button className="btn btn-danger" onClick={downloadPDF}>Download PDF</button>
          <button className="btn btn-success" onClick={downloadDOCX}>Download Word</button>
          <button className="btn btn-secondary" onClick={()=>window.print()}>Print</button>
        </div>
        <div className="paper-preview">
          <div className="text-center">
            <h3>{paper.schoolName}</h3>
            <h4>{paper.title}</h4>
            <p><b>Time:</b> {paper.duration} &nbsp;&nbsp;&nbsp; <b>Maximum Marks:</b> {paper.totalMarks}</p>
          </div>
          <h5>General Instructions</h5>
          <ol>{paper.instructions.map((x,i)=><li key={i}>{x}</li>)}</ol>
          {paper.sections.map((sec,si)=>{
            let base=paper.sections.slice(0,si).reduce((n,s)=>n+s.questions.length,0);
            return <section key={sec._id||si}><h5 className="mt-4">{sec.name}</h5>{sec.questions.map((q,qi)=><div className="question-row" key={q._id}><div><b>{base+qi+1}.</b> {q.text} <span className="float-end">[{q.marks}]</span></div>{q.type==="MCQ"&&<ol type="A">{q.options.map((o,i)=><li key={i}>{o}</li>)}</ol>}</div>)}</section>
          })}
        </div>
      </div>}
    </Layout>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login/>}/>
        <Route path="/" element={<Protected><Dashboard/></Protected>}/>
        <Route path="/questions" element={<Protected><Questions/></Protected>}/>
        <Route path="/generate" element={<Protected><Generate/></Protected>}/>
        <Route path="*" element={<Navigate to="/" replace/>}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
